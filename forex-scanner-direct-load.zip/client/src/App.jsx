import ForexScanner from './components/ForexScanner'
export default function App(){ return (<div className="min-h-screen p-4"><ForexScanner/></div>) }
