Forex Scanner — Direct Load (Vercel + Render) Ready
--------------------------------------------------
1) Extract and push this repo to GitHub.
2) On Render: create Web Service using `server` directory. Set TWELVED_API_KEY in Render environment variables.
3) On Vercel: import project; set build command `npm run build` and output `dist` for client. Set env VITE_API_BASE_URL to the Render backend URL.
4) After deploy, your Vercel URL will directly load the Scanner in the browser (no local run needed).
